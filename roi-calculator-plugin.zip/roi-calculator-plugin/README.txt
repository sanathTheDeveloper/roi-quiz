=== ROI Calculator - Health Reception Reinvented ===
Contributors: 24/7 AI Healthcare Receptionist
Tags: roi, calculator, healthcare, ai, lead generation
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI Healthcare Reception ROI Calculator - Help practices calculate their potential savings.

== Description ==

The ROI Calculator helps Australian healthcare practices quantify cost savings and efficiency gains from adopting AI phone reception systems.

**Features:**

* 15+ step interactive quiz
* Real-time ROI calculations in 3 categories:
  - Staffing savings (FTE reduction)
  - Revenue recovery (missed calls)
  - No-show savings (AI reminders)
* Interactive results with charts
* Lead capture and CRM integration
* Fully responsive design
* No header/footer - integrates with your theme

**Usage:**

Simply add the shortcode `[roi_calculator]` to any page or post.

**Requirements:**

* Active internet connection (connects to Supabase backend)
* Modern browser (Chrome, Firefox, Safari, Edge)

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/roi-calculator-plugin/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Add the shortcode `[roi_calculator]` to any page
4. Done!

== Frequently Asked Questions ==

= How do I add the calculator to my site? =

Add the shortcode `[roi_calculator]` to any page or post.

= Can I customize the calculator? =

The calculator has built-in styling. You can control the container width and height using shortcode attributes:
`[roi_calculator width="900px" min-height="800px"]`

= Where are leads stored? =

Leads are automatically saved to Supabase and synced to EngageBay CRM (if marketing consent is given).

= Is it mobile-friendly? =

Yes! The calculator is fully responsive and works on all devices.

== Shortcode ==

**Basic usage:**
`[roi_calculator]`

**With custom width:**
`[roi_calculator width="900px"]`

**With custom height:**
`[roi_calculator min-height="800px"]`

== Changelog ==

= 1.0.0 =
* Initial release
* Full ROI calculator functionality
* Supabase integration
* EngageBay CRM sync
* Mobile responsive design

== Upgrade Notice ==

= 1.0.0 =
Initial release - Install and activate!
