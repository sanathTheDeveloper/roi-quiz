<?php
/**
 * Plugin Name: ROI Calculator - Health Reception Reinvented
 * Plugin URI: https://247aihealthcarereceptionist.com
 * Description: Embeds the AI Healthcare Reception ROI Calculator using shortcode [roi_calculator]
 * Version: 1.0.0
 * Author: 24/7 AI Healthcare Receptionist
 * Author URI: https://247aihealthcarereceptionist.com
 * License: GPL v2 or later
 * Text Domain: roi-calculator
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue React app assets
 */
function roi_calc_enqueue_assets() {
    // Only load on pages that have the shortcode
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'roi_calculator')) {

        $plugin_url = plugin_dir_url(__FILE__);

        // Enqueue Google Fonts (required by the app)
        wp_enqueue_style(
            'roi-calc-fonts',
            'https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&family=Instrument+Sans:wght@400;500;600;700&display=swap',
            array(),
            null
        );

        // Enqueue main CSS
        wp_enqueue_style(
            'roi-calc-css',
            $plugin_url . 'dist/assets/style.css',
            array(),
            '1.0.0'
        );

        // Enqueue main JavaScript (as module)
        wp_enqueue_script(
            'roi-calc-js',
            $plugin_url . 'dist/assets/roi-quiz.js',
            array(),
            '1.0.0',
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'roi_calc_enqueue_assets');

// Add module type filter globally (not inside enqueue function)
add_filter('script_loader_tag', 'roi_calc_add_type_module', 10, 3);

/**
 * Add type="module" to the calculator script
 */
function roi_calc_add_type_module($tag, $handle, $src) {
    if ('roi-calc-js' === $handle) {
        // Remove WordPress's default script tag attributes and add module type
        $tag = '<script type="module" crossorigin src="' . esc_url($src) . '"></script>';
    }
    return $tag;
}

/**
 * Add module preload support
 */
function roi_calc_add_modulepreload() {
    echo '<script>
!function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll(\'link[rel="modulepreload"]\'))n(r);new MutationObserver(r=>{for(const t of r)if(t.type==="childList")for(const o of t.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function n(r){if(r.ep)return;r.ep=!0;const t={};r.integrity&&(t.integrity=r.integrity),r.referrerPolicy&&(t.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?t.credentials="include":r.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",fetch(r.href,t)}}();
</script>';
}

/**
 * Hook modulepreload polyfill on pages with shortcode
 */
function roi_calc_maybe_add_modulepreload() {
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'roi_calculator')) {
        add_action('wp_head', 'roi_calc_add_modulepreload', 1);
    }
}
add_action('wp', 'roi_calc_maybe_add_modulepreload');

/**
 * Shortcode to output the React app root div
 */
function roi_calculator_shortcode($atts) {
    // Parse attributes with defaults
    $atts = shortcode_atts(
        array(
            'width' => '100%',
            'min-height' => '600px',
        ),
        $atts,
        'roi_calculator'
    );

    // Output the React root div with optional styling
    $style = sprintf(
        'width: %s; min-height: %s;',
        esc_attr($atts['width']),
        esc_attr($atts['min-height'])
    );

    return sprintf(
        '<div id="root" style="%s"></div>',
        $style
    );
}
add_shortcode('roi_calculator', 'roi_calculator_shortcode');

/**
 * Add settings link to plugin page
 */
function roi_calc_add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=roi-calculator') . '">Instructions</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'roi_calc_add_settings_link');

/**
 * Add admin menu for instructions
 */
function roi_calc_admin_menu() {
    add_options_page(
        'ROI Calculator Instructions',
        'ROI Calculator',
        'manage_options',
        'roi-calculator',
        'roi_calc_instructions_page'
    );
}
add_action('admin_menu', 'roi_calc_admin_menu');

/**
 * Display instructions page
 */
function roi_calc_instructions_page() {
    ?>
    <div class="wrap">
        <h1>ROI Calculator - Usage Instructions</h1>

        <div class="card" style="max-width: 800px; padding: 20px; margin-top: 20px;">
            <h2>Plugin Activated Successfully!</h2>

            <h3>How to Use:</h3>
            <ol>
                <li><strong>Add to any page or post:</strong> Use the shortcode <code>[roi_calculator]</code></li>
                <li><strong>Publish the page</strong></li>
                <li><strong>View the page</strong> - The ROI Calculator will appear!</li>
            </ol>

            <hr>

            <h3>Shortcode Options:</h3>
            <p><strong>Basic usage:</strong></p>
            <pre>[roi_calculator]</pre>

            <p><strong>Custom width:</strong></p>
            <pre>[roi_calculator width="900px"]</pre>

            <p><strong>Custom minimum height:</strong></p>
            <pre>[roi_calculator min-height="800px"]</pre>

            <hr>

            <h3> Recommended Setup:</h3>
            <ul>
                <li>Create a new page called "ROI Calculator"</li>
                <li>Use a <strong>Full Width</strong> page template (if your theme has one)</li>
                <li>Add the shortcode: <code>[roi_calculator]</code></li>
                <li>Publish!</li>
            </ul>

            <hr>

            <h3> Lead Integration:</h3>
            <p>All leads are automatically saved to:</p>
            <ul>
                <li> <strong>Supabase Database</strong> (Project: gzvcxhygpnmopfocktfy)</li>
                <li> <strong>EngageBay CRM</strong> (if marketing consent is given)</li>
            </ul>

            <hr>

            <h3> Styling Notes:</h3>
            <ul>
                <li>The calculator uses its own styles and won't conflict with your theme</li>
                <li>It's fully responsive (mobile, tablet, desktop)</li>
                <li>No header/footer included - uses your WordPress theme's navigation</li>
            </ul>

            <hr>

            <h3> What the Calculator Does:</h3>
            <ul>
                <li>Guides users through 15+ questions about their practice</li>
                <li>Calculates ROI in 3 categories: Staffing, Revenue Recovery, No-Show Reduction</li>
                <li>Shows personalized results with charts</li>
                <li>Captures leads with contact information</li>
                <li>Syncs to EngageBay CRM automatically</li>
            </ul>

            <hr>

            <h3> Need Help?</h3>
            <p>If the calculator doesn't appear:</p>
            <ol>
                <li>Clear your WordPress cache (if using a caching plugin)</li>
                <li>Clear your browser cache (Ctrl+Shift+R or Cmd+Shift+R)</li>
                <li>Check that the shortcode is spelled correctly: <code>[roi_calculator]</code></li>
                <li>Try viewing in a different browser</li>
            </ol>

            <hr>

            <h3> Documentation:</h3>
            <p>For technical details, see the README files included with the plugin.</p>

            <div style="background: #e7f3ff; border-left: 4px solid #0073aa; padding: 15px; margin-top: 20px;">
                <strong> You're all set!</strong><br>
                The ROI Calculator is ready to use on your WordPress site.
            </div>
        </div>
    </div>
    <?php
}

/**
 * Activation hook
 */
function roi_calc_activate() {
    // Nothing to do on activation, but keeping for future use
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'roi_calc_activate');

/**
 * Deactivation hook
 */
function roi_calc_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'roi_calc_deactivate');
